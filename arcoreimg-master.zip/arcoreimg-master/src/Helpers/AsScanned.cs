﻿namespace arcoreimg_app.Helpers
{
    public class AsScanned
    {
        public string Image { get; set; }

        public string Title { get; set; }

        public int Score { get; set; }

        public string Itemid { get; internal set; }
    }
}
