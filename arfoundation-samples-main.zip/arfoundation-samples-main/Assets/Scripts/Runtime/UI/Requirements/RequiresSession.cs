using UnityEngine.XR.ARSubsystems;

namespace UnityEngine.XR.ARFoundation.Samples
{
    public class RequiresSession : RequiresARSubsystem<XRSessionSubsystem, XRSessionSubsystemDescriptor>
    { }
}
